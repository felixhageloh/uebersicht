(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
var UebersichtServer, args, e, error, handleError, parseArgs, port, ref, ref1, ref2, ref3, ref4, ref5, server, settingsPath, widgetPath;

parseArgs = require('minimist');

UebersichtServer = require('./src/app.coffee');

handleError = function(e) {
  return console.log('Error:', e.message);
};

try {
  args = parseArgs(process.argv.slice(2));
  widgetPath = (ref = (ref1 = args.d) != null ? ref1 : args.dir) != null ? ref : './widgets';
  port = (ref2 = (ref3 = args.p) != null ? ref3 : args.port) != null ? ref2 : 41416;
  settingsPath = (ref4 = (ref5 = args.s) != null ? ref5 : args.settings) != null ? ref4 : './settings';
  server = UebersichtServer(Number(port), widgetPath, settingsPath, function() {
    return console.log('server started on port', port);
  });
  server.on('close', handleError);
} catch (error) {
  e = error;
  handleError(e);
}


},{"./src/app.coffee":7,"minimist":undefined}],2:[function(require,module,exports){
'use strict';

const WebSocket = require('ws');

module.exports = function MessageBus(options) {
  const wss = new WebSocket.Server(options);

  function broadcast(data) {
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(data);
      }
    });
  }

  wss.on('connection', function connection(ws) {
    ws.on('message', broadcast);
  });

  return wss;
};

},{"ws":undefined}],3:[function(require,module,exports){
'use strict';

const path = require('path');
const fs = require('fs');

module.exports = function Settings(settingsDirPath) {
  const api = {};
  let settings;

  const fullSettingsDirPath = path.resolve(__dirname, settingsDirPath);
  const settingsFile = path.join(fullSettingsDirPath, 'WidgetSettings.json');

  initSettingsFile(fullSettingsDirPath);

  function initSettingsFile(dirPath) {
    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath);
    }
  }

  api.load = function load() {
    let persistedSettings = {};
    try {
      persistedSettings = require(settingsFile);
    } catch (e) { /* do nothing */ }

    return persistedSettings;
  };

  api.persist = function persist(newSettings) {
    if (newSettings !== settings) {
      fs.writeFile(settingsFile, JSON.stringify(newSettings), (err) => {
        if (err) {
          console.log(err);
        } else {
          settings = newSettings;
        }
      });
    }
  };

  return api;
};

},{"fs":undefined,"path":undefined}],4:[function(require,module,exports){
'use strict';

const WebSocket = typeof window !== 'undefined'
  ? window.WebSocket
  : require('ws');

let ws = null;
let isOpen = false;

const messageListeners = [];
const openListeners = [];

function handleWSOpen() {
  isOpen = true;
  openListeners.forEach((f) => f());
}

function handleWSCosed() {
  isOpen = false;
}

function handleMessage(data) {
  messageListeners.forEach((f) => f(data));
}

exports.open = function open(url) {
  ws = new WebSocket(url);

  if (ws.on) {
    ws.on('open', handleWSOpen);
    ws.on('close', handleWSCosed);
    ws.on('message', handleMessage);
  } else {
    ws.onopen = handleWSOpen;
    ws.onclose = handleWSCosed;
    ws.onmessage = (e) => handleMessage(e.data);
  }
};

exports.close = function close() {
  ws.close();
  ws = null;
};

exports.isOpen = function() {
  return ws && isOpen;
};

exports.onMessage = function onMessage(listener) {
  messageListeners.push(listener);
};

exports.onOpen = function onOpen(listener) {
  openListeners.push(listener);
};

exports.send = function send(data) {
  ws.send(data);
};


},{"ws":undefined}],5:[function(require,module,exports){
'use strict';

// middleware to serve the current state
module.exports = (store) => (req, res, next) => {
  if (req.url === '/state/') {
    res.end(JSON.stringify(store.getState()));
  } else {
    next();
  }
};

},{}],6:[function(require,module,exports){
'use strict';

exports.addWidget = function widgetLoaded(widget) {
  return {
    type: 'WIDGET_ADDED',
    payload: widget,
  };
};

exports.removeWidget = function removeWidget(id) {
  return {
    type: 'WIDGET_REMOVED',
    payload: id,
  };
};

exports.applyWidgetSettings = function applyWidgetSettings(id, settings) {
  return {
    type: 'WIDGET_SETTINGS_CHANGED',
    payload: { id: id, settings: settings },
  };
};

},{}],7:[function(require,module,exports){
var CommandServer, MessageBus, Settings, StateServer, WidgetDirWatcher, actions, connect, dispatchToRemote, fs, listenToRemote, path, reducer, redux, serveClient, sharedSocket;

connect = require('connect');

path = require('path');

fs = require('fs');

redux = require('redux');

MessageBus = require('./MessageBus');

WidgetDirWatcher = require('./widget_directory_watcher.coffee');

Settings = require('./Settings');

StateServer = require('./StateServer');

CommandServer = require('./command_server.coffee');

serveClient = require('./serveClient');

sharedSocket = require('./SharedSocket');

actions = require('./actions');

reducer = require('./reducer');

dispatchToRemote = require('./dispatch');

listenToRemote = require('./listen');

module.exports = function(port, widgetPath, settingsPath, callback) {
  var action, dirWatcher, id, messageBus, ref, server, settings, store, value;
  store = redux.createStore(reducer, {
    widgets: {},
    settings: {},
    screens: []
  });
  listenToRemote(function(action) {
    return store.dispatch(action);
  });
  widgetPath = path.resolve(__dirname, widgetPath);
  dirWatcher = WidgetDirWatcher(widgetPath);
  dirWatcher.on('widget', function(widget) {
    var action;
    action = actions.addWidget(widget);
    store.dispatch(action);
    return dispatchToRemote(action);
  });
  dirWatcher.on('widgetRemoved', function(id) {
    var action;
    action = actions.removeWidget(id);
    store.dispatch(action);
    return dispatchToRemote(action);
  });
  settings = Settings(settingsPath);
  ref = settings.load();
  for (id in ref) {
    value = ref[id];
    action = actions.applyWidgetSettings(id, value);
    store.dispatch(action);
    dispatchToRemote(action);
  }
  store.subscribe(function() {
    return settings.persist(store.getState().settings);
  });
  messageBus = null;
  server = connect().use(CommandServer(widgetPath)).use(StateServer(store)).use(connect["static"](path.resolve(__dirname, './public'))).use(connect["static"](widgetPath)).use(serveClient).listen(port, '127.0.0.1', function() {
    messageBus = MessageBus({
      server: server
    });
    sharedSocket.open("ws://127.0.0.1:" + port);
    return typeof callback === "function" ? callback() : void 0;
  });
  return {
    close: function() {
      dirWatcher.close();
      server.close();
      return messageBus.close();
    },
    on: function(ev, handler) {
      return server.on(ev, handler);
    }
  };
};


},{"./MessageBus":2,"./Settings":3,"./SharedSocket":4,"./StateServer":5,"./actions":6,"./command_server.coffee":8,"./dispatch":9,"./listen":10,"./reducer":13,"./serveClient":14,"./widget_directory_watcher.coffee":16,"connect":undefined,"fs":undefined,"path":undefined,"redux":undefined}],8:[function(require,module,exports){
var spawn;

spawn = require('child_process').spawn;

module.exports = function(workingDir) {
  return function(req, res, next) {
    var command, shell;
    if (!(req.method === 'POST' && req.url === '/run/')) {
      return next();
    }
    shell = spawn('bash', ['-l'], {
      cwd: workingDir
    });
    command = '';
    req.on('data', function(chunk) {
      return command += chunk;
    });
    return req.on('end', function() {
      var setStatus;
      setStatus = function(status) {
        res.writeHead(status);
        return setStatus = function() {};
      };
      shell.stderr.on('data', function(d) {
        setStatus(500);
        return res.write(d);
      });
      shell.stdout.on('data', function(d) {
        setStatus(200);
        return res.write(d);
      });
      shell.on('error', function(err) {
        setStatus(500);
        return res.write(err.message);
      });
      shell.on('close', function() {
        setStatus(200);
        return res.end();
      });
      shell.stdin.write(command != null ? command : '');
      shell.stdin.write('\n');
      return shell.stdin.end();
    });
  };
};


},{"child_process":undefined}],9:[function(require,module,exports){
'use strict';

const ws = require('./SharedSocket');
const queuedMessages = [];

function drainQueuedMessages() {
  queuedMessages.forEach((m) => ws.send(m));
  queuedMessages.length = 0;
}

ws.onOpen(drainQueuedMessages);

module.exports = function dispatch(message) {
  const serializedMessage = JSON.stringify(message);

  if (ws.isOpen()) {
    ws.send(serializedMessage);
  } else {
    queuedMessages.push(serializedMessage);
  }
};

},{"./SharedSocket":4}],10:[function(require,module,exports){
'use strict';

const ws = require('./SharedSocket');
const listeners = [];

ws.onMessage(function handleMessage(data) {
  let message;
  try { message = JSON.parse(data); } catch (e) { null; }

  if (message) {
    listeners.forEach((f) => f(message));
  }
});

module.exports = function listen(callback) {
  listeners.push(callback);
};

},{"./SharedSocket":4}],11:[function(require,module,exports){
var fs, loadWidget, parseWidget, prettyPrintError, toSource, validateWidget;

fs = require('fs');

toSource = require('tosource');

parseWidget = require('./parseWidget');

validateWidget = require('./validateWidget');

prettyPrintError = function(filePath, error) {
  var errStr;
  if (error.code === 'ENOENT') {
    return 'file not found';
  }
  errStr = (typeof error.toString === "function" ? error.toString() : void 0) || String(error.message);
  if (errStr.indexOf("[stdin]") > -1) {
    errStr = errStr.replace("[stdin]", filePath);
  } else {
    errStr = filePath + ': ' + errStr;
  }
  return errStr;
};

module.exports = loadWidget = function(id, filePath, callback) {
  var respond, respondWithError, result;
  result = {
    id: id,
    filePath: filePath
  };
  respond = function(widgetBody) {
    result.body = '(' + toSource(widgetBody) + ')';
    return callback(result);
  };
  respondWithError = function(error) {
    result.error = prettyPrintError(filePath, error);
    return callback(result);
  };
  return fs.readFile(filePath, {
    encoding: 'utf8'
  }, function(err, data) {
    var body, error1, issues;
    if (err) {
      return respondWithError(err);
    }
    try {
      body = parseWidget(id, filePath, data);
    } catch (error1) {
      err = error1;
      return respondWithError(err);
    }
    issues = validateWidget(body);
    if (issues && issues.length > 0) {
      return respondWithError(id + ': ' + issues.join(', '));
    } else {
      return respond(body);
    }
  });
};


},{"./parseWidget":12,"./validateWidget":15,"fs":undefined,"tosource":undefined}],12:[function(require,module,exports){
// can't use strict here, because widgets will get evaled as strict as well

var coffee = require('coffee-script');
var stylus = require('stylus');
var nib = require('nib');
var ms = require('ms');

function parseStyle(id, style) {
  var css = '';

  if (style) {
    var scopedStyle = '#' + id + '\n  ' + style.replace(/\n/g, '\n  ');
    css = stylus(scopedStyle)
      .import('nib')
      .use(nib())
      .render();
  }

  return css;
}

module.exports = function parseWidget(id, filePath, body) {
  var parsed;

  if (filePath.match(/\.coffee$/)) {
    parsed = coffee.eval(body);
  } else {
    parsed = eval('({' + body + '})');
  }

  if (typeof parsed.refreshFrequency === 'string') {
    parsed.refreshFrequency = ms(parsed.refreshFrequency);
  }

  if (!parsed.css) {
    parsed.css = parseStyle(id, parsed.style || '');
    delete parsed.style;
  }

  parsed.id = id;
  return parsed;
};

},{"coffee-script":undefined,"ms":undefined,"nib":undefined,"stylus":undefined}],13:[function(require,module,exports){
'use strict';

const defaultSettings = {
  showOnAllScreens: true,
  showOnMainScreen: false,
  showOnSelectedScreens: false,
  screens: [],
};

const handlers = {

  WIDGET_ADDED: (state, action) => {
    const widget = action.payload;
    const newWidgets = Object.assign({}, state.widgets, {
      [widget.id]: widget,
    });

    const settings = state.settings || {};
    const newSettings = settings[widget.id]
      ? state.settings
      : Object.assign({}, settings, { [widget.id]: defaultSettings });

    return Object.assign({},
      state,
      { widgets: newWidgets, settings: newSettings }
    );
  },

  WIDGET_REMOVED: (state, action) => {
    const id = action.payload;

    if (!state.widgets[id]) {
      return state;
    }

    const newWidgets = Object.assign({}, state.widgets);
    delete newWidgets[id];

    return Object.assign({}, state, { widgets: newWidgets });
  },

  WIDGET_SETTINGS_CHANGED: (state, action) => {
    const newSettings = Object.assign({},
      state.settings,
      { [action.payload.id]: action.payload.settings }
    );

    return Object.assign({}, state, { settings: newSettings });
  },

  WIDGET_SET_TO_ALL_SCREENS: (state, action) => {
    return updateSettings(state, action.payload, {
      showOnAllScreens: true,
      showOnSelectedScreens: false,
      showOnMainScreen: false,
      screens: [],
    });
  },

  WIDGET_SET_TO_SELECTED_SCREENS: (state, action) => {
    return updateSettings(state, action.payload, {
      showOnSelectedScreens: true,
      showOnAllScreens: false,
      showOnMainScreen: false,
    });
  },

  WIDGET_SET_TO_MAIN_SCREEN: (state, action) => {
    return updateSettings(state, action.payload, {
      showOnSelectedScreens: false,
      showOnAllScreens: false,
      showOnMainScreen: true,
      screens: [],
    });
  },

  SCREEN_SELECTED_FOR_WIDGET: (state, action) => {
    const settings = state.settings[action.payload.id];
    const newScreens = (settings.screens || []).slice();

    if (newScreens.indexOf(action.payload.screenId) === -1) {
      newScreens.push(action.payload.screenId);
    }

    return updateSettings(state, action.payload.id, {
      screens: newScreens,
    });
  },

  SCREEN_DESELECTED_FOR_WIDGET: (state, action) => {
    const newScreens = (state.settings[action.payload.id].screens || [])
      .filter((s) => s !== action.payload.screenId);

    return updateSettings(state, action.payload.id, {
      screens: newScreens,
    });
  },

  SCREENS_DID_CHANGE: (state, action) => {
    return Object.assign({}, state, {
      screens: action.payload,
    });
  },
};

function updateSettings(state, widgetId, patch) {
  const widgetSettings = state.settings[widgetId];
  const newSettings = Object.assign({},
    state.settings,
    { [widgetId]: Object.assign({}, widgetSettings, patch) }
  );

  return Object.assign({}, state, { settings: newSettings });
}

module.exports = function reduce(state, action) {
  let newState;

  const handler = handlers[action.type];
  if (handler) {
    newState = handler(state, action);
  } else {
    newState = state;
  }

  return newState;
};

},{}],14:[function(require,module,exports){
'use strict';

const fs = require('fs');
const path = require('path');
const stream = require('stream');

const indexHTML = fs.readFileSync(
  path.resolve(
    __dirname,
    path.join('public', 'index.html')
  )
);

module.exports = function serveClient(req, res, next) {
  const bufferStream = new stream.PassThrough();
  bufferStream.pipe(res);
  bufferStream.end(indexHTML);
};

},{"fs":undefined,"path":undefined,"stream":undefined}],15:[function(require,module,exports){
'use strict';

function validateHasCommand(impl, issues, message) {
  if (typeof impl.command !== 'string' && impl.refreshFrequency !== false) {
    issues.push(message);
  }
}

module.exports = function validateWidget(impl) {
  const issues = [];

  if (impl) {
    validateHasCommand(impl, issues, 'no command given');
  } else {
    issues.push('empty implementation');
  }

  return issues;
};

},{}],16:[function(require,module,exports){
var EventEmitter, fs, fsevents, loadWidget, paths;

paths = require('path');

fs = require('fs');

fsevents = require('fsevents');

EventEmitter = require('events');

loadWidget = require('./loadWidget.coffee');

module.exports = function(directoryPath) {
  var api, emitWidget, eventEmitter, findRemovedWidgets, findWidgets, getPathType, init, isWidgetPath, watcher, widgetId, widgetPaths;
  api = {};
  widgetPaths = {};
  watcher = null;
  eventEmitter = new EventEmitter();
  init = function() {
    if (fs.lstatSync(directoryPath).isSymbolicLink()) {
      directoryPath = fs.readlinkSync(directoryPath);
    }
    directoryPath = directoryPath.normalize();
    if (!fs.existsSync(directoryPath)) {
      throw new Error("could not find widget dir at " + directoryPath);
    }
    watcher = fsevents(directoryPath);
    watcher.on('change', function(filePath, info) {
      switch (info.event) {
        case 'modified':
        case 'moved-in':
        case 'created':
          return findWidgets(filePath, info.type, function(widgetPath) {
            widgetPaths[widgetPath] = true;
            return emitWidget(widgetPath);
          });
        case 'moved-out':
        case 'deleted':
          return findRemovedWidgets(filePath, function(widgetPath) {
            eventEmitter.emit('widgetRemoved', widgetId(widgetPath));
            return delete widgetPaths[widgetPath];
          });
      }
    });
    watcher.start();
    console.log('watching', directoryPath);
    findWidgets(directoryPath, 'directory', function(widgetPath) {
      widgetPaths[widgetPath] = true;
      return emitWidget(widgetPath);
    });
    return api;
  };
  api.close = function() {
    eventEmitter.removeAllListeners();
    return watcher.stop();
  };
  api.on = function(type, handler) {
    return eventEmitter.on(type, handler);
  };
  api.off = function(type, handler) {
    return eventEmitter.removeListener(type, handler);
  };
  emitWidget = function(filePath) {
    var id;
    id = widgetId(filePath);
    return loadWidget(id, filePath, function(widget) {
      return eventEmitter.emit('widget', widget);
    });
  };
  findWidgets = function(path, type, onFound) {
    if (type === 'file') {
      if (isWidgetPath(path)) {
        return onFound(path.normalize());
      }
    } else {
      return fs.readdir(path, function(err, subPaths) {
        var fullPath, i, len, results, subPath;
        if (err) {
          return console.log(err);
        }
        results = [];
        for (i = 0, len = subPaths.length; i < len; i++) {
          subPath = subPaths[i];
          fullPath = paths.join(path, subPath);
          results.push(getPathType(fullPath, function(p, t) {
            return findWidgets(p, t, onFound);
          }));
        }
        return results;
      });
    }
  };
  findRemovedWidgets = function(filePath, onFound) {
    var i, len, ref, results, widgetPath;
    filePath = filePath.normalize();
    ref = Object.keys(widgetPaths);
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      widgetPath = ref[i];
      if (widgetPath.indexOf(filePath) === 0) {
        results.push(onFound(widgetPath));
      } else {
        results.push(void 0);
      }
    }
    return results;
  };
  getPathType = function(path, callback) {
    return fs.stat(path, function(err, stat) {
      var type;
      if (err) {
        return console.log(err);
      }
      type = stat.isDirectory() ? 'directory' : 'file';
      return callback(path, type);
    });
  };
  widgetId = function(filePath) {
    var fileParts, part;
    fileParts = filePath.replace(directoryPath, '').split(/\/+/);
    fileParts = (function() {
      var i, len, results;
      results = [];
      for (i = 0, len = fileParts.length; i < len; i++) {
        part = fileParts[i];
        if (part) {
          results.push(part);
        }
      }
      return results;
    })();
    return fileParts.join('-').replace(/\./g, '-').replace(/\s/g, '_');
  };
  isWidgetPath = function(filePath) {
    return /\.coffee$|\.js$/.test(filePath);
  };
  return init();
};


},{"./loadWidget.coffee":11,"events":undefined,"fs":undefined,"fsevents":undefined,"path":undefined}]},{},[1]);
