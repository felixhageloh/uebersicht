import { css } from "uebersicht";
import CardTable from "./src/CardTable";

const cardColor = "rgba(255, 255, 255, 0.7)";

export const className = css`
  bottom: 5px;
  left: 5px;
`;
export const refreshFrequency = 1000;
export const command = `ps axro \"%cpu,ucomm,pid\" \
  | sed -e 's/^[ \\t]*//g' -e 's/\\([0-9][0-9]*\\.[0-9][0-9]*\\)\\ /\\1\\%\\,/g' -e 's/\\ \\ *\\([0-9][0-9]*$\\)/\\,\\1/g' -e's/\\ \\ */\\_/g' \
  | awk 'FNR>1' \
  | head -n 3 \
  | awk -F',' '{ printf \"%s,%s,%d\\n\", $1, $2, $3}' \
  | sed -e 's/\\_/\\ /g'`;

export const initialState = { cards: [] };
export function updateState({ output = "", error }) {
  const rows = output
    .split("\n")
    .filter(row => row)
    .map(row => {
      const [text, subText, superText] = row.split(",");
      return { text, subText, superText };
    });
  return { cards: rows || [], error };
}

export function render({ cards, error }) {
  return error ? (
    String(error)
  ) : (
    <CardTable cards={cards} color={cardColor} width="420px" />
  );
}
