import { css } from "uebersicht";

const card = css`
  height: 46px;
  box-shadow: 0 0 40px rgba(0, 0, 0, 0.2);
  -webkit-backdrop-filter: blur(20px) saturate(1.2);
  text-decoration: none;
  display: block;
  & + & {
    margin-left: 5px;
  }
`;
const alpha = css`
  fill: #fff;
`;
const bg = css`
  fill: rgba(255, 255, 255, 0.9);
`;
const main = css`
  font-size: 18px;
  font-weight: 700;
  letter-spacing: -0.5px;
  text-anchor: start;
`;
const detail = css`
  font-size: 9px;
  font-weight: 600;
  text-anchor: start;
  opacity: 0.7;
`;
const superScript = css`
  text-anchor: end;
  font-size: 10px;
  font-family: Ubuntu Mono, mono;
  font-weight: 500;
`;

const rand = Math.round(Math.random() * 1000000);
export default function Card(props) {
  const {
    text,
    subText,
    superText,
    idx,
    bgColor,
    textColor,
    superTextColor,
    subTextColor,
    url
  } = props;
  const mask = `mask_${new Date().getTime()}_${idx}_${rand}`;

  return (
    <a className={card} href={url}>
      <svg width="100%" height="100%">
        <defs>
          <mask id={mask} x="0" y="0" width="100%" height="100%">
            <rect className={alpha} x="0" y="0" width="100%" height="100%" />
            {!textColor && (
              <text className={main} x="11px" y="0%" dy="22px">
                {text}
              </text>
            )}
            {!subTextColor && (
              <text className={detail} x="11px" y="100%" dy="-8px">
                {subText}
              </text>
            )}
            {!superTextColor && (
              <text className={superScript} x="100%" y="0%" dx="-7px" dy="14px">
                {superText}
              </text>
            )}
          </mask>
        </defs>
        <rect
          fill={bgColor}
          mask={`url(#${mask})`}
          x="0"
          y="0"
          width="100%"
          height="100%"
        />
        {textColor && (
          <text className={main} fill={textColor} x="11px" y="0%" dy="22px">
            {text}
          </text>
        )}
        {subTextColor && (
          <text
            className={detail}
            fill={subTextColor}
            x="11px"
            y="100%"
            dy="-8px"
          >
            {subText}
          </text>
        )}
        {superTextColor && (
          <text
            className={superScript}
            fill={superTextColor}
            x="100%"
            y="0%"
            dx="-7px"
            dy="14px"
          >
            {superText}
          </text>
        )}
      </svg>
    </a>
  );
}
