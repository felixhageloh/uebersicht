import { css } from "uebersicht";
import Card from "./Card";

const table = css`
  display: flex;
  font-family: -apple-system;
`;

export default function CardTable({ cards, width, color }) {
  return (
    <div className={css(table, { width })}>
      {cards.map((props, idx) => {
        const { text, subText, superText, ...rest } = props;
        return (
          <Card
            text={text}
            subText={subText}
            superText={superText}
            key={idx}
            idx={idx}
            bgColor={color}
            {...rest}
          />
        );
      })}
    </div>
  );
}
